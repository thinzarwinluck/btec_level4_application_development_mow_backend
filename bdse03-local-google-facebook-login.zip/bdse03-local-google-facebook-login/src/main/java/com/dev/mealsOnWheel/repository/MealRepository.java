package com.dev.mealsOnWheel.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.dev.mealsOnWheel.dao.Meals;

public interface MealRepository extends JpaRepository<Meals,Long> {

}
