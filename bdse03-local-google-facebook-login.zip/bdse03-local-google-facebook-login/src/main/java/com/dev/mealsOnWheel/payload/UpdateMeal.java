package com.dev.mealsOnWheel.payload;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.dev.mealsOnWheel.dao.Users;

public class UpdateMeal {

   
    private Long id;
    private String name;
    private String tag;
    private String description;
    private Boolean coldmeal_available;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTag() {
		return tag;
	}
	public void setTag(String tag) {
		this.tag = tag;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Boolean getColdmeal_available() {
		return coldmeal_available;
	}
	public void setColdmeal_available(Boolean coldmeal_available) {
		this.coldmeal_available = coldmeal_available;
	}
    
    
}
