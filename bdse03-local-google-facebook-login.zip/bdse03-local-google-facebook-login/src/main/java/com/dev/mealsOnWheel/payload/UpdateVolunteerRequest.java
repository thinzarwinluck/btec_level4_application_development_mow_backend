package com.dev.mealsOnWheel.payload;

public class UpdateVolunteerRequest {

	private int caregiver_id;
	private String caregiver_name;
	public int getCaregiver_id() {
		return caregiver_id;
	}
	public void setCaregiver_id(int caregiver_id) {
		this.caregiver_id = caregiver_id;
	}
	public String getCaregiver_name() {
		return caregiver_name;
	}
	public void setCaregiver_name(String caregiver_name) {
		this.caregiver_name = caregiver_name;
	}
	

}
