package com.dev.mealsOnWheel.dao;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
public class Meals {
	
    @Id
    @Column(name="id")
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Long id;

    @Column(name="name")
    private String name;
    
    @Column(name="tag")
    private String tag;
    
    @Column(name="description")
    private String description;
    
    @Column(name="coldmeal_available")
    private Boolean coldmeal_available;
    @ManyToOne
    @JoinColumn(name = "user_id")
    private Users user;
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTag() {
		return tag;
	}

	public void setTag(String tag) {
		this.tag = tag;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Users getUser() {
		return user;
	}

	public void setUser(Users user) {
		this.user = user;
	}

	public Boolean getColdmeal_available() {
		return coldmeal_available;
	}

	public void setColdmeal_available(Boolean coldmeal_available) {
		this.coldmeal_available = coldmeal_available;
	}
	
	

	

	
	

	
	

    
  
	
	
	
 

}
