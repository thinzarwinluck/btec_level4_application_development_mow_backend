package com.dev.mealsOnWheel.controller;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dev.mealsOnWheel.dao.AuthProvider;
import com.dev.mealsOnWheel.dao.Meals;
import com.dev.mealsOnWheel.dao.Users;
import com.dev.mealsOnWheel.exception.ResourceNotFoundException;
import com.dev.mealsOnWheel.payload.UpdateMeal;
import com.dev.mealsOnWheel.repository.MealRepository;
import com.dev.mealsOnWheel.repository.UsersRepository;
@RestController
@RequestMapping(value = "/api")
public class MealController {

	@Autowired
	MealRepository m_repo;

	@Autowired
	UsersRepository usersRepository;

	@PostMapping("/save/meal/{user_id}")
	public Meals saveMeal(@RequestBody Meals meal, @PathVariable Long user_id) {
		// Retrieve the user by userId
		Users user = usersRepository.findById(user_id).orElse(null);
		meal.setUser(user);
		return m_repo.save(meal);
	};

	@GetMapping("/meals")
	public ResponseEntity<List<Meals>> getallstores() {
	    try {
	        List<Meals> allStores = m_repo.findAll();
	        return ResponseEntity.ok(allStores);
	    } catch (Exception e) {
	        // Log the exception for debugging
	       
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
	    }
	}
	
	@PutMapping("/meals/edit/{id}")
	public ResponseEntity<Void> updateMeal(@PathVariable Long id, @RequestBody UpdateMeal updatedMeal) {
	    Optional<Meals> optionalMeal = m_repo.findById(id);
	    if (optionalMeal.isEmpty()) {
	        throw new ResourceNotFoundException("Meal", "id", id);
	    }
	    Meals existingMeal = optionalMeal.get();
	    existingMeal.setName(updatedMeal.getName());
	    existingMeal.setDescription(updatedMeal.getDescription());
	    existingMeal.setColdmeal_available(updatedMeal.getColdmeal_available());
	    existingMeal.setTag(updatedMeal.getTag());
	    existingMeal.setUser(existingMeal.getUser());

	    m_repo.save(existingMeal);
	    return ResponseEntity.ok().build();
	}
	
	@DeleteMapping("/meals/delete/{id}")
	public ResponseEntity<Void> deleteMeal(@PathVariable Long id) {
	    Optional<Meals> optionalMeal = m_repo.findById(id);
	    if (optionalMeal.isEmpty()) {
	        throw new ResourceNotFoundException("Meal", "id", id);
	    }

	    Meals existingMeal = optionalMeal.get();
	    m_repo.delete(existingMeal);

	    return ResponseEntity.ok().build();
	}

}