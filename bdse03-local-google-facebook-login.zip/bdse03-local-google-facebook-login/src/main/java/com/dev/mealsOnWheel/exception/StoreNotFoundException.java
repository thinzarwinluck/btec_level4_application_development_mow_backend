package com.dev.mealsOnWheel.exception;

public class StoreNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8451124621180535660L;

	public StoreNotFoundException(String string) {
		System.out.println("Store Not Found Exception Class");
	}

}
