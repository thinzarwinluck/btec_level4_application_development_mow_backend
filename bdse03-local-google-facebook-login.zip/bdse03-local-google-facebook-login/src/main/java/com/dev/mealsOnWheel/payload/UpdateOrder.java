package com.dev.mealsOnWheel.payload;


public class UpdateOrder {
	
	
	private int volunteer_id;
	private String volunteer_name;
	public int getVolunteer_id() {
		return volunteer_id;
	}
	public void setVolunteer_id(int volunteer_id) {
		this.volunteer_id = volunteer_id;
	}
	public String getVolunteer_name() {
		return volunteer_name;
	}
	public void setVolunteer_name(String volunteer_name) {
		this.volunteer_name = volunteer_name;
	}
	
	
	


}
