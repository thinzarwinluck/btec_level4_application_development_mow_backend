package com.dev.mealsOnWheel.dao;

public enum AuthProvider {
	google,
	facebook,
	local
}
