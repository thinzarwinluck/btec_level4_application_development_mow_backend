package com.dev.mealsOnWheel.payload;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;

public class Register {
	
private String experience;
	
	private String previous_work;
	
	private String user_profile;
	private String health;
	private String information;
	private String age;
	
	private String phone;
	@NotBlank
	private String userName;
	
	@Email
	@NotBlank
	private String email; 
	
	@NotBlank
	private String password;
	
	
	@NotBlank
	private BigDecimal latitude;
	
	@NotBlank
	private BigDecimal longitude;

	@NotBlank
	private String location;
	
	private String role;
	private Boolean duty;
	private Boolean need_support;

	
	
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	public BigDecimal getLatitude() {
		return latitude;
	}
	public void setLatitude(BigDecimal latitude) {
		this.latitude = latitude;
	}
	public BigDecimal getLongitude() {
		return longitude;
	}
	public void setLongitude(BigDecimal longitude) {
		this.longitude = longitude;
	}
	public String getExperience() {
		return experience;
	}
	public void setExperience(String experience) {
		this.experience = experience;
	}
	public String getPrevious_work() {
		return previous_work;
	}
	public void setPrevious_work(String previous_work) {
		this.previous_work = previous_work;
	}
	public String getUser_profile() {
		return user_profile;
	}
	public void setUser_profile(String user_profile) {
		this.user_profile = user_profile;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getHealth() {
		return health;
	}
	public void setHealth(String health) {
		this.health = health;
	}
	public String getInformation() {
		return information;
	}
	public void setInformation(String information) {
		this.information = information;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public Boolean getDuty() {
		return duty;
	}
	public void setDuty(Boolean duty) {
		this.duty = duty;
	}
	public Boolean getNeed_support() {
		return need_support;
	}
	public void setNeed_support(Boolean need_support) {
		this.need_support = need_support;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
