package com.dev.mealsOnWheel.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dev.mealsOnWheel.dao.AuthProvider;
import com.dev.mealsOnWheel.dao.Users;
import com.dev.mealsOnWheel.exception.ResourceNotFoundException;
import com.dev.mealsOnWheel.repository.UsersRepository;
import com.dev.mealsOnWheel.service.UsersPrincipal;

@RestController
@RequestMapping("/api")
public class UsersController {

    private final UsersRepository usersRepo;

    @Autowired
    public UsersController(UsersRepository usersRepo) {
        this.usersRepo = usersRepo;
    }

    @GetMapping("/user/me")
    public Users getUser(@CurrentUser UsersPrincipal usersPrincipal) {
        Long userId = usersPrincipal.getUsersId();
        return usersRepo.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Users", "userId", userId));
    }

    @GetMapping("/user/getAll")
    public List<Users> getAllUsers(@CurrentUser UsersPrincipal usersPrincipal) {
        // You can use the usersPrincipal information as needed
      
        List<Users> allUsers = usersRepo.findAll();
        
        // Optionally, you can exclude the current user from the list if needed
       
        return allUsers;
    };
    
   

}
