package com.dev.mealsOnWheel.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dev.mealsOnWheel.dao.*;
import com.dev.mealsOnWheel.exception.ResourceNotFoundException;
import com.dev.mealsOnWheel.payload.UpdateOrder;
import com.dev.mealsOnWheel.payload.UpdateVolunteerRequest;
import com.dev.mealsOnWheel.repository.*;

@RestController
@RequestMapping(value = "/api")
public class OrderController {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private UsersRepository userRepository;

    @Autowired
    private MealRepository mealRepository;

    @PostMapping("/order/save/user/{user_id}/meal/{meal_id}")
    public Order saveOrder(@RequestBody Order order, @PathVariable Long user_id, @PathVariable Long meal_id) {
        Users user = userRepository.findById(user_id).orElseThrow(() -> new ResourceNotFoundException("User", "id", user_id));
        Meals meal = mealRepository.findById(meal_id).orElseThrow(() -> new ResourceNotFoundException("Meal", "id", meal_id));
        order.setUser(user);
        order.setMeal(meal);
        return orderRepository.save(order);
    }

    @GetMapping("/order/getAll")
    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }

    @PutMapping("/order/assign/volunteer/{order_id}")
    public ResponseEntity<Void> assignVolunteer(@PathVariable Long order_id, @RequestBody UpdateOrder updateOrderRequest) {
        Order existingOrder = orderRepository.findById(order_id)
                .orElseThrow(() -> new ResourceNotFoundException("Order", "id", order_id));

        existingOrder.setVolunteer_id(updateOrderRequest.getVolunteer_id());
        existingOrder.setVolunteer_name(updateOrderRequest.getVolunteer_name());

        orderRepository.save(existingOrder);

        return ResponseEntity.ok().build();
    }
    @CrossOrigin
    @PutMapping("/order/assign/care-giver/{order_id}")
    public ResponseEntity<Void> assignCareGiver(@PathVariable Long order_id, @RequestBody UpdateVolunteerRequest updateVolunteerRequest) {
        Order existingOrder = orderRepository.findById(order_id)
                .orElseThrow(() -> new ResourceNotFoundException("Order", "id", order_id));

        existingOrder.setCaregiver_id(updateVolunteerRequest.getCaregiver_id());
        existingOrder.setCaregiver_name(updateVolunteerRequest.getCaregiver_name());

        orderRepository.save(existingOrder);

        return ResponseEntity.ok().build();
    }
}
