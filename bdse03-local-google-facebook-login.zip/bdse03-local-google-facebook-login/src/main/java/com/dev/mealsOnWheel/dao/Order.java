package com.dev.mealsOnWheel.dao;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name = "orders")
public class Order {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long ordersId;
	@ManyToOne
	@JoinColumn(name = "user_id")
	private Users user;
	@ManyToOne
	@JoinColumn(name = "meal_id")
	private Meals meal;
	@JsonIgnore
	@Column(name = "volunteer_id")
	private int volunteer_id;

	@Column(name = "volunteer_name")
	private String volunteer_name;

	@Column(name = "caregiver_id")
	private int caregiver_id;

	@Column(name = "caregiver_name")
	private String caregiver_name;

	public long getOrdersId() {
		return ordersId;
	}

	public void setOrdersId(long ordersId) {
		this.ordersId = ordersId;
	}

	public Users getUser() {
		return user;
	}

	public void setUser(Users user) {
		this.user = user;
	}

	public Meals getMeal() {
		return meal;
	}

	public void setMeal(Meals meal) {
		this.meal = meal;
	}

	public int getVolunteer_id() {
		return volunteer_id;
	}

	public void setVolunteer_id(int volunteer_id) {
		this.volunteer_id = volunteer_id;
	}

	public String getVolunteer_name() {
		return volunteer_name;
	}

	public void setVolunteer_name(String volunteer_name) {
		this.volunteer_name = volunteer_name;
	}

	public int getCaregiver_id() {
		return caregiver_id;
	}

	public void setCaregiver_id(int caregiver_id) {
		this.caregiver_id = caregiver_id;
	}

	public String getCaregiver_name() {
		return caregiver_name;
	}

	public void setCaregiver_name(String caregiver_name) {
		this.caregiver_name = caregiver_name;
	}

}
