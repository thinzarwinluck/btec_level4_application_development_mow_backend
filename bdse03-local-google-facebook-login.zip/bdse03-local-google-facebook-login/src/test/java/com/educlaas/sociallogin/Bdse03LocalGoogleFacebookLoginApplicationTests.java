package com.educlaas.sociallogin;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;

import com.dev.mealsOnWheel.dao.Users;
import com.dev.mealsOnWheel.payload.Login;
import com.dev.mealsOnWheel.repository.UsersRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

@SpringBootTest
@AutoConfigureMockMvc
class Bdse03LocalGoogleFacebookLoginApplicationTests {

    @Autowired
    private UsersRepository usersRepository;

    @Autowired
    private MockMvc mockMvc;

    @Test
    void contextLoads() {
        // Your existing contextLoads test logic, if any
    }

    @Test
    void userEmailCheck() {
        String email = "john@gmail.com";
        // Find user by email
        Optional<Users> usersOptional = usersRepository.findByEmail(email);

        // Check if user exists
        if (usersOptional.isPresent()) {
            Users users = usersOptional.get();
            assertNotNull(users);
            // Add additional assertions based on your requirements
        } else {
            // Handle the case when the user is not found
            // You might want to log a message or fail the test, depending on your needs
            System.out.println("User with email " + email + " not found.");
        }
    }

//    @Test
//    public void userLoginTest() throws Exception {
//        Login loginRequest = new Login();
//        loginRequest.setEmail("thinzar@gmail.com");
//        loginRequest.setPassword("abcd12345");
//
//        mockMvc.perform(MockMvcRequestBuilders.post("/kyn/login")
//                .contentType(MediaType.APPLICATION_JSON)
//                .content(asJsonString(loginRequest)))
//                .andExpect(MockMvcResultMatchers.status().isOk())
//                .andExpect(MockMvcResultMatchers.jsonPath("$.accessToken").exists())
//                .andDo(result -> {
//                    // Check for the console output
//                    String responseBody = result.getResponse().getContentAsString();
//                    if (responseBody.contains("accessToken")) {
//                        System.out.println("Login successful!");
//                    } else {
//                        System.out.println("Login failed!");
//                    }
//                });
//    }
//
//
//    // Utility method to convert an object to JSON string
//    private String asJsonString(final Object obj) {
//        try {
//            return new ObjectMapper().writeValueAsString(obj);
//        } catch (JsonProcessingException e) {
//            throw new RuntimeException(e);
//        }
//    }




}


